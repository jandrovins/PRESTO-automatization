// The most RAM for a single core to use in accelsearch
#define MAXRAMUSE             2000000000
// The longest length FFT to do in core memory
#define MAXREALFFT            1000000000
// The biggest length FFT to use FFTW for (if larger, use 6-step)
#define BIGFFTWSIZE           200000000
